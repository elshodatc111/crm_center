<?php $__env->startSection('title','Kassa'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Kassa</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item">Kassa</li>
        </ol>
    </nav>
</div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title text-center w-100">
                    <i class="bi bi-cash-coin me-1 text-success"></i> Kassada mavjud summa
                </h3>
                <ul class="list-group">
                    <li class="list-group-item">
                        <i class="bi bi-cash-stack me-1 text-success"></i> Naqt: <b><?php echo e(number_format($getKassa['naqt'], 0, '.', ' ')); ?></b> so'm
                    </li>
                    <li class="list-group-item">
                        <i class="bi bi-credit-card-2-front me-1 text-primary"></i> Plastik: <b><?php echo e(number_format($getKassa['plastik'], 0, '.', ' ')); ?></b> so'm
                    </li>
                </ul>
                <button class="btn btn-primary w-100 mt-3" data-bs-toggle="modal" data-bs-target="#refundModal">
                    <i class="bi bi-arrow-counterclockwise me-1"></i> Qaytarilgan to'lovlar
                </button>
            </div>
        </div>
    </div> 

    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title text-center w-100">
                    <i class="bi bi-arrow-down-circle me-1 text-danger"></i> Chiqim kutilmoqda
                </h3>
                <ul class="list-group">
                    <li class="list-group-item">
                        <i class="bi bi-box-arrow-down me-1 text-danger"></i> Naqt: <b><?php echo e(number_format($getKassa['naqt_chiq_pedding'], 0, '.', ' ')); ?></b> so'm
                    </li>
                    <li class="list-group-item">
                        <i class="bi bi-credit-card me-1 text-warning"></i> Plastik: <b><?php echo e(number_format($getKassa['plastik_chiq_pedding'], 0, '.', ' ')); ?></b> so'm
                    </li>
                </ul>
                <button class="btn btn-primary w-100 mt-3" data-bs-toggle="modal" data-bs-target="#expenseModal">
                    <i class="bi bi-box-arrow-right me-1"></i> Kassadan chiqim
                </button>
            </div>
        </div>
    </div>


    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title text-center w-100">
                    <i class="bi bi-cart-check me-1 text-warning"></i> Tasdiqlanmagan chiqimlar
                </h3>
                <div class="table-responsive">
                    <table class="table table-bordered text-center" style="font-size:14px">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Meneger</th>
                                <th>Chiqim turi</th>
                                <th>Chimim summasi</th>
                                <th>Chiqim vaqti</th>
                                <th>Chiqim haqida</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pedding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['user_name']); ?></td>
                                    <td>
                                        <?php if($item['type']=='naqt_chiq'): ?>
                                            <i class="text-primary">Kassadan chiqim (Naqt)</i>
                                        <?php elseif($item['type']=='plastik_chiq'): ?>
                                            <i class="text-primary">Kassadan chiqim (Plastik)</i>
                                        <?php elseif($item['type']=='naqt_xar'): ?>
                                            <i class="text-danger">Kassadan xarajat (Naqt)</i>
                                        <?php elseif($item['type']=='plastik_xar'): ?>
                                            <i class="text-danger">Kassadan xarajat (Plastik)</i>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item['amount']); ?></td>
                                    <td><?php echo e($item['create_time']); ?></td>
                                    <td><?php echo e($item['description']); ?></td>
                                    <td>
                                        <div class="d-flex gap-2 text-center">
                                            <?php if(auth()->user()->type != 'meneger'): ?>
                                                <form action="<?php echo e(route('compamy_kassa_success')); ?>" method="post" class="d-inline-block">
                                                    <?php echo csrf_field(); ?> 
                                                    <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                                    <button type="submit" class="btn btn-success px-1 py-0"><i class="bi bi-check"></i></button>
                                                </form>
                                            <?php endif; ?>
                                            <form action="<?php echo e(route('compamy_kassa_delete')); ?>" method="post" class="d-inline-block">
                                                <?php echo csrf_field(); ?> 
                                                <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                                <button type="submit" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center">Tasdiqlanmagan chiqim va xarajatlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="refundModal" tabindex="-1" aria-labelledby="refundModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- modal-lg kengroq variant -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="refundModalLabel">
                    <i class="bi bi-arrow-counterclockwise me-1"></i> Qaytarilgan to'lovlar (oxirgi 7 kun)
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" style="font-size:14px">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Talaba</th>
                                <th>Qaytarilgan</th>
                                <th>Qaytarish sababi</th>
                                <th>Qaytarilgan vaqt</th>
                                <th>Meneger</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $returnPaymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="td"><?php echo e($loop->index+1); ?></td>
                                    <td><a href="<?php echo e(route('student_show',$item['user_id'])); ?>"><?php echo e($item['user_name']); ?></a></td>
                                    <td class="td"><?php echo e($item['amount']); ?></td>
                                    <td class="td"><?php echo e($item['description']); ?></td>
                                    <td class="td"><?php echo e($item['created_at']); ?></td>
                                    <td class="td"><?php echo e($item['admin']); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=5 class="text-center">Oxirgi 7 kunda qaytarilgan to'lovlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="expenseModal" tabindex="-1" aria-labelledby="expenseModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="expenseModalLabel">
                    <i class="bi bi-box-arrow-right me-1"></i> Kassadan chiqim
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered text-center" style="font-size:14px;">
                    <thead>
                        <tr>
                            <th colspan=2>Kassada mavjud</th>
                        </tr>
                        <tr>
                            <th>Naqt</th>
                            <th>Plastik</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e(number_format($getKassa['naqt'], 0, '.', ' ')); ?> so'm</td>
                            <td><?php echo e(number_format($getKassa['plastik'], 0, '.', ' ')); ?> so'm</td>
                        </tr>
                    </tbody>
                </table>
                <form action="<?php echo e(route('compamy_kassa_chiqim')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="naqt" value="<?php echo e($getKassa['naqt']); ?>">
                    <input type="hidden" name="plastik" value="<?php echo e($getKassa['plastik']); ?>">
                    <label for="amount" class="my-2">Chiqim summasi</label>
                    <input type="text" name="amount" id="paymentAmount01" required class="form-control">
                    <script>
                        document.getElementById('paymentAmount01').addEventListener('input', function(event) {
                            let input = event.target.value.replace(/\D/g, ''); 
                            let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " "); 
                            event.target.value = formatted;
                        });
                    </script>
                    <label for="type" class="my-2">Chiqim turi</label>
                    <select name="type" required class="form-select">
                        <option value="naqt">Naqt</option>
                        <option value="plastik">Plastik</option>
                    </select>
                    <label for="description" class="my-2">Chiqim haqida</label>
                    <textarea name="description" class="form-control mb-2" required></textarea>
                    <div class="row">
                        <div class="col-6">
                            <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary w-100" data-bs-dismiss="modal">Saqlash</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app01', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/kassa/index.blade.php ENDPATH**/ ?>