<?php $__env->startSection('title','To\'lovlar Statistika'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>To'lovlar</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('chart_paymart')); ?>">To'lovlkar statistikasi</a></li>
            <li class="breadcrumb-item">Kunlik to'lovlar</li>
        </ol>
    </nav>
</div>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Kunlik to'lovlar (<?php echo e($data); ?>)</h4>
            <div class="table-responsive">
                <table class="table table-bordered text-center" style="font-size:12px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>To'lov summasi</th>
                            <th>To'lov turi</th>
                            <th>To'lov haqida</th>
                            <th>To'lov vaqti</th>
                            <th>Meneger</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $paymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><a href="<?php echo e(route('student_show',$item['user_id'])); ?>"><?php echo e($item['user_name']); ?></a></td>
                            <td>
                                <?php echo e(number_format($item['amount'], 0, '.', ' ')); ?>    
                            </td>
                            <td>
                                <?php if($item['paymart_type']=='naqt'): ?>
                                    <span class="badge bg-success">Naqt</span>
                                <?php elseif($item['paymart_type']=='plastik'): ?>
                                    <span class="badge bg-primary">Plastik</span>
                                <?php elseif($item['paymart_type']=='chegirma'): ?>
                                    <span class="badge bg-warning text-white">Chegirma</span>
                                <?php elseif($item['paymart_type']=='qaytarildi'): ?>
                                    <span class="badge bg-danger">Qaytarildi</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item['description']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['email']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan=7 class="text-center">To'lovlar mavjud emas.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app03', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/chart/show.blade.php ENDPATH**/ ?>