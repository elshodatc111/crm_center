
<?php $__env->startSection('title','Yuborilgan smslar'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h3 class="card-title w-100 text-center mb-0 pb-0">Yuborilgan smslar</h3>
        <form action="<?php echo e(route('report_message_next')); ?>" method="get" class="row">
            <div class="col-lg-4 col-12">
                <select name="type" required class="form-select my-2">
                    <option value="">Tanlang</option>
                    <option value="send_message">Yuborilgan smslar</option>
                </select>
            </div>
            <div class="col-lg-3 col-6">
                <input type="date" name="start" required class="form-control my-2">
            </div>
            <div class="col-lg-3 col-6">
                <input type="date" name="end" required class="form-control my-2">
            </div>
            <div class="col-lg-2 col-12">
                <button class="btn btn-primary my-2" type="submit">Qidruv</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/report/message.blade.php ENDPATH**/ ?>