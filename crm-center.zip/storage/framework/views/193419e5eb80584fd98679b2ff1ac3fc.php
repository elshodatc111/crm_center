<header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center text-center justify-content-between">
      <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center" >
        <span class="d-block d-lg-none">CRM</span>
        <span class="d-none d-lg-block">CRM Center</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">
        <li class="nav-item dropdown">
          <a class="nav-link nav-icon" href="#">
            <i class="bi bi-cake2"></i>
            <span class="badge bg-success badge-number"><?php echo $__env->make('layouts.tkun', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link nav-icon" href="<?php echo e(route('meneger_varonka_new')); ?>">
            <i class="bi bi-bell"></i>
            <span class="badge bg-info badge-number"><?php echo $__env->make('layouts.murojat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
          </a>
        </li>
        <li class="nav-item dropdown pe-3">
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle" style="font-size: 25px;"></i>
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e(auth()->user()->email); ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo e(auth()->user()->user_name); ?></h6>
              <span><?php echo e(auth()->user()->email); ?></span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-person"></i>
                <span>Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="bi bi-box-arrow-right"></i>
                <span>Chiqish</span>
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
              </form>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
  </header>

  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['home', 'dashboard']) ? '' : 'collapsed'); ?>" href="<?php echo e(route('home')); ?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link  <?php echo e(request()->routeIs(['all_student','student_show']) ? '' : 'collapsed'); ?>" href="<?php echo e(route('all_student')); ?>">
          <i class="bi bi-people"></i>
          <span>Tashriflar</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['all_groups','create_show']) ? '' : 'collapsed'); ?> " href="<?php echo e(route('all_groups')); ?>">
          <i class="bi bi-menu-button-wide"></i>
          <span>Guruhlar</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['meneger_varonka','meneger_varonka_show','meneger_varonka_cancel','meneger_varonka_new','meneger_varonka_pedding','meneger_varonka_success'])? '' : 'collapsed'); ?>" href="<?php echo e(route('meneger_varonka')); ?>">
          <i class="bi bi-inboxes"></i>
          <span>Murojatlar</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['compamy_kassa','compamy_kassa'])? '' : 'collapsed'); ?>" href="<?php echo e(route('compamy_kassa')); ?>">
          <i class="bi bi-cash-stack"></i>
          <span>Kassa</span>
        </a>
      </li>
      <?php if(auth()->user()->type === 'sAdmin' || auth()->user()->type === 'admin'): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['compamy_moliya'])? '' : 'collapsed'); ?>" href="<?php echo e(route('compamy_moliya')); ?>">
          <i class="bi bi-graph-up"></i>
          <span>Moliya</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['report_users','report_paymart','report_users_next','report_group_next','report_message_next','report_group','report_paymart_next','report_message']) ? '' : 'collapsed'); ?>" data-bs-target="#report-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-receipt"></i><span>Hisobot</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="report-nav" class="nav-content collapse <?php echo e(request()->routeIs(['report_users','report_group_next','report_message_next','report_users_next','report_paymart','report_paymart_next','report_group','report_message']) ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(route('report_users')); ?>"  class="<?php echo e(request()->routeIs(['report_users','report_users_next']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Talabalar</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('report_paymart')); ?>"  class="<?php echo e(request()->routeIs(['report_paymart','report_paymart_next']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>To'lovlar</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('report_group')); ?>"  class="<?php echo e(request()->routeIs(['report_group','report_group_next']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Guruhlar</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('report_message')); ?>"  class="<?php echo e(request()->routeIs(['report_message','report_message_next']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>SMS</span>
            </a>
          </li>
        </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['all_techer','techer_show']) ? '' : 'collapsed'); ?> " href="<?php echo e(route('all_techer')); ?>">
          <i class="bi bi-briefcase"></i>
          <span>O'qituvchilar</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['compamy_hodim','compamy_hodim_show']) ? '' : 'collapsed'); ?>" href="<?php echo e(route('compamy_hodim')); ?>">
          <i class="bi bi-card-list"></i>
          <span>Hodimlar</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link  <?php echo e(request()->routeIs(['chart_vised','chart_paymart','chart_techer','chart_paymart_show','chart_techer_reyting']) ? '' : 'collapsed'); ?>" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bar-chart"></i><span>Statistika</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="charts-nav" class="nav-content collapse <?php echo e(request()->routeIs(['chart_vised','chart_paymart','chart_techer','chart_paymart_show','chart_techer_reyting']) ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(route('chart_vised')); ?>" class="<?php echo e(request()->routeIs(['chart_vised']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Tashrif Statistikasi</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('chart_paymart')); ?>" class="<?php echo e(request()->routeIs(['chart_paymart','chart_paymart_show']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>To'lovlar Statistikasi</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('chart_techer')); ?>" class="<?php echo e(request()->routeIs(['chart_techer']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Guruhlar Statistikasi</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('chart_techer_reyting')); ?>" class="<?php echo e(request()->routeIs(['chart_techer_reyting']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>O'qituvchilar Reyting</span>
            </a>
          </li>
        </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(request()->routeIs(['setting_cours','all_social','setting_sms', 'setting_holiday','setting_paymart','setting_chegirma','setting_rooms']) ? '' : 'collapsed'); ?>" data-bs-target="#gear-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-gear"></i><span>Sozlamalar</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="gear-nav" class="nav-content collapse <?php echo e(request()->routeIs(['setting_cours','all_social','setting_sms', 'setting_holiday','setting_paymart','setting_chegirma','setting_rooms']) ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(route('setting_sms')); ?>" class="<?php echo e(request()->routeIs(['setting_sms']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>SMS sozlamalari</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('setting_holiday')); ?>" class="<?php echo e(request()->routeIs(['setting_holiday']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Dam olish va bayram kunlari</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('setting_paymart')); ?>" class="<?php echo e(request()->routeIs(['setting_paymart']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>To'lov sozlamalari</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('setting_chegirma')); ?>"  class="<?php echo e(request()->routeIs(['setting_chegirma']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Chegirmali to'lov</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('setting_rooms')); ?>" class="<?php echo e(request()->routeIs(['setting_rooms']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Dars xonalari</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('setting_cours')); ?>" class="<?php echo e(request()->routeIs(['setting_cours']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Kurslar</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('all_social')); ?>" class="<?php echo e(request()->routeIs(['all_social']) ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Hududlar</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if(auth()->user()->type === 'sAdmin'): ?>
        <li class="nav-item">
          <a class="nav-link <?php echo e(request()->routeIs(['sadmin_setting', 'sadmin_sms', 'sadmin_time']) ? '' : 'collapsed'); ?>" data-bs-target="#setting-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-gear"></i><span>Settings</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="setting-nav" class="nav-content collapse <?php echo e(request()->routeIs(['sadmin_setting', 'sadmin_sms', 'sadmin_time']) ? 'show' : ''); ?>" data-bs-parent="#sidebar-nav">
            <li>
              <a href="<?php echo e(route('sadmin_setting')); ?>" class="<?php echo e(request()->routeIs(['sadmin_setting']) ? 'active' : ''); ?>">
                <i class="bi bi-circle"></i><span>Tizim sozlamalari</span>
              </a>
            </li>
            <li>
              <a href="<?php echo e(route('sadmin_time')); ?>" class="<?php echo e(request()->routeIs(['sadmin_time']) ? 'active' : ''); ?>">
                <i class="bi bi-circle"></i><span>Dars vaqtlari</span>
              </a>
            </li>
            <li>
              <a href="<?php echo e(route('sadmin_sms')); ?>" class="<?php echo e(request()->routeIs(['sadmin_sms']) ? 'active' : ''); ?>">
                <i class="bi bi-circle"></i><span>SMS paketlari</span>
              </a>
            </li>
          </ul>
        </li>
      <?php endif; ?>
    </ul>
  </aside>
  
  <main id="main" class="main">

    <?php echo $__env->yieldContent('content'); ?>

  </main>

  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
    <strong><span>CodeStart</span></strong> Dev Center
    </div>
  </footer>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/layouts/layout.blade.php ENDPATH**/ ?>