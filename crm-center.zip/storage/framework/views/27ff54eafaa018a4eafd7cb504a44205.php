<?php $__env->startSection('title','SMS paketlari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>SMS paketlari</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">SMS paketlari</li>
            </ol>
        </nav>
    </div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">SMS paketlari</h3>
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Mavjud Paketlar soni</th>
                            <th>Jami yuborilganlar soni</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($Setting['message_mavjud']); ?></td>
                            <td><?php echo e($Setting['message_count']); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Yangi SMS paket</h3>
                <form action="<?php echo e(route('sadmin_message_mavjud')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="message_mavjud">SMSlar soni</label>
                    <input type="number" name="message_mavjud" required class="form-control">
                    <button type="submit" class="btn btn-primary w-100 mt-2">O'zgarishlarni saqlash</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">SMS yuborish holati (<?php echo e($Setting['message_status']==1?'Aktive':'Block'); ?>)</h3>
                <form action="<?php echo e(route('sadmin_message_status')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="status">SMS yuborish holatini tanlang</label>
                    <select type="text" name="status" required class="form-select">
                        <option value="">Tanlang</option>
                        <option value='1'>Aktiv</option>
                        <option value='0'>Block</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100 mt-2">O'zgarishlarni saqlash</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/sadmin/sms.blade.php ENDPATH**/ ?>