
<?php $__env->startSection('title','Yuborilgan sms xabarlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Hisobot</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('report_message')); ?>">SMS</a></li>
                <li class="breadcrumb-item">Hisobot</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-9">
                    <h3 class="card-title w-100 mb-0 pb-0">
                        Yuborilgan smslar (Data Start: <?php echo e($response['start']); ?> - Data End: <?php echo e($response['end']); ?>)
                    </h3>
                </div>
                <div class="col-3" style="text-align:right">
                    <button id='export' class="btn btn-primary mt-3" type="button">Print Excel</button>
                </div>
            </div>
            <div class="table-responsive pt-2">
                <table class="table table-bordered text-center" id="table" style="font-size:12px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Telefon raqam</th>
                            <th>SMS matni</th>
                            <th>Yuborildi</th>
                            <th>Meneger</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $response['message']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($item['phone']); ?></td>
                            <td><?php echo e($item['message']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['admin']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=5 class="text-center">Yuborilgan smslar mavjud emas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/report/message_next.blade.php ENDPATH**/ ?>