
<?php $__env->startSection('title','Guruhlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>To'lovlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('report_group')); ?>">Guruhlar</a></li>
                <li class="breadcrumb-item">Guruhlar</li>
            </ol>
        </nav>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-9">
                    <h3 class="card-title w-100 mb-0 pb-0">
                        <?php if($type=='all'): ?>
                            Barcha Guruhlar
                        <?php elseif($type=='test'): ?>
                            Test natijalari
                        <?php endif; ?> 
                    </h3>
                </div>
                <div class="col-3" style="text-align:right">
                    <button id='export' class="btn btn-primary mt-3" type="button">Print Excel</button>
                </div>
            </div>
            <?php if($type=='all'): ?>
                <div class="table-responsive pt-2">
                    <table class="table table-bordered text-center" id="table" style="font-size:12px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kurs nomi</th>
                                <th>Guruh nomi</th>
                                <th>To'lov summasi</th>
                                <th>To'lov uchun chegirma</th>
                                <th>Admin uchun chegirma</th>
                                <th>Hafta kuni</th>
                                <th>Darslar soni</th>
                                <th>Dars xonasi</th>
                                <th>Dars vaqti</th>
                                <th>O'qituvchi</th>
                                <th>O'qituvchiga to'lov</th>
                                <th>O'qituvchiga bonus</th>
                                <th>Boshlanish vaqti</th>
                                <th>Yakunlanish vaqti</th>
                                <th>Meneger</th>
                                <th>Guruh Status</th>
                                <th>Guruh yaratildi</th>
                                <th>Guruh yangilandi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['Cours']); ?></td>
                                    <td><?php echo e($item['group_name']); ?></td>
                                    <td><?php echo e($item['amount']); ?></td>
                                    <td><?php echo e($item['chegirma']); ?></td>
                                    <td><?php echo e($item['admin_chegirma']); ?></td>
                                    <td><?php echo e($item['weekday']); ?></td>
                                    <td><?php echo e($item['lessen_count']); ?></td>
                                    <td><?php echo e($item['xona']); ?></td>
                                    <td><?php echo e($item['lessen_times_id']); ?></td>
                                    <td><?php echo e($item['techer']); ?></td>
                                    <td><?php echo e($item['techer_paymart']); ?></td>
                                    <td><?php echo e($item['techer_bonus']); ?></td>
                                    <td><?php echo e($item['lessen_start']); ?></td>
                                    <td><?php echo e($item['lessen_end']); ?></td>
                                    <td><?php echo e($item['meneger']); ?></td>
                                    <td><?php echo e($item['next']); ?></td>
                                    <td><?php echo e($item['created_at']); ?></td>
                                    <td><?php echo e($item['updated_at']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=19 class="text-center">Guruhlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php elseif($type=='test'): ?>
                <div class="table-responsive pt-2">
                    <table class="table table-bordered text-center" id="table" style="font-size:12px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Talaba</th>
                                <th>Kurs</th>
                                <th>Guruh</th>
                                <th>Testlar soni</th>
                                <th>Urinishlar soni</th>
                                <th>To'g'ri javob</th>
                                <th>Noto'g'ri javob</th>
                                <th>Ball</th>
                                <th>Birinchi urinish vaqti</th>
                                <th>Oxirgi urinish vaqti</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['user']); ?></td>
                                    <td><?php echo e($item['kurs']); ?></td>
                                    <td><?php echo e($item['guruh']); ?></td>
                                    <td>15</td>
                                    <td><?php echo e($item['urinishlar']); ?></td>
                                    <td><?php echo e($item['tugri']); ?></td>
                                    <td><?php echo e($item['notugri']); ?></td>
                                    <td><?php echo e($item['ball']); ?></td>
                                    <td><?php echo e($item['first']); ?></td>
                                    <td><?php echo e($item['end']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=10 class="text-center">Test natijalari mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
            <?php endif; ?> 
            
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/report/group_next.blade.php ENDPATH**/ ?>