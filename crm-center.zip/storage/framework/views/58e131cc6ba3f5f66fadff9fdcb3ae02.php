<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h3 class="card-title w-100 text-center mb-0 pb-0">Dars Jadvali</h3>
        <div class="accordion accordion-flush" id="faq-group-2">
            <?php $__empty_1 = true; $__currentLoopData = $jadval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                <button class="accordion-button <?php echo e($key==0?'':'collapsed'); ?>" data-bs-target="#faqsTwo-<?php echo e($key); ?>" type="button" data-bs-toggle="collapse">
                    <?php echo e($value['date']); ?> | <?php echo e($value['day']); ?>

                </button>
                </h2>
                <div id="faqsTwo-<?php echo e($key); ?>" class="accordion-collapse <?php echo e($key==0?'':'collapse'); ?>" data-bs-parent="#faq-group-2">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Guruh</th>
                                        <th>Dars Xonasi</th>
                                        <th>Dars vaqt</th>
                                        <th>O'quvchilar soni</th>
                                        <th>O'qituvchi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_2 = true; $__currentLoopData = $value['item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><a href="<?php echo e(route('create_show',$item['group_id'])); ?>"><?php echo e($item['group_name']); ?></a></td>
                                        <td><?php echo e($item['room']); ?></td>
                                        <td><?php echo e($item['time']); ?></td>
                                        <td><?php echo e($item['count']); ?></td>
                                        <td><a href="<?php echo e(route('techer_show',$item['techer_id'])); ?>"><?php echo e($item['techer_name']); ?></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <tr>
                                        <td colspan=6 class="text-center">Darslar mavjud emas.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/home.blade.php ENDPATH**/ ?>