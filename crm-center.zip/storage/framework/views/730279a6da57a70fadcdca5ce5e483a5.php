<?php $__env->startSection('title','Tashrif Statistika'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center">Hududlardan tashriflar</h5>
                <div id="HududCharts"></div>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#HududCharts"), {
                            series: [
                                <?php $__currentLoopData = $Hudud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item['count']); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],
                            chart: {
                                height: 320,
                                type: 'pie',
                                toolbar: {
                                    show: true
                                }
                            },
                            labels: [
                                <?php $__currentLoopData = $Hudud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    "<?php echo e($item['name']); ?>",
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        }).render();
                    });
                </script>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center">Sotsial tashriflar</h5>
                <div id="pieChart"></div>
                <script>
                document.addEventListener("DOMContentLoaded", () => {
                    new ApexCharts(document.querySelector("#pieChart"), {
                    series: [
                        <?php echo e($Social['telegram']); ?>,
                        <?php echo e($Social['instagram']); ?>,
                        <?php echo e($Social['facebook']); ?>,
                        <?php echo e($Social['youtube']); ?>,
                        <?php echo e($Social['bannner']); ?>,
                        <?php echo e($Social['tanish']); ?>,
                        <?php echo e($Social['boshqa']); ?>,
                    ],
                    chart: {
                        height: 320,
                        type: 'pie',
                        toolbar: {
                            show: true
                        }
                    },
                    labels: ['Telegram', 'Instagram', 'Facebook', 'Youtube', 'Banner','Tanishlar','Boshqa']
                    }).render();
                });
                </script>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Tashriflar</h4>
                <div id="columnChart"></div>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#columnChart"), {
                        series: [{
                            name: 'Tashriflar',
                            data: [
                                <?php $__currentLoopData = $tashrif['tashrif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        },{
                            name: 'Guruhga biriktirildi',
                            data: [
                                <?php $__currentLoopData = $tashrif['group']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        }, {
                            name: 'To\'lov qilid',
                            data: [
                                <?php $__currentLoopData = $tashrif['paymart']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        }, {
                            name: 'Aktiv talabalar',
                            data: [
                                <?php $__currentLoopData = $activeUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                        }],
                        chart: {
                            type: 'bar',
                            height: 350
                        },
                        plotOptions: {
                            bar: {
                            horizontal: false,
                            columnWidth: '55%',
                            endingShape: 'rounded'
                            },
                        },
                        dataLabels: {
                            enabled: false
                        },
                        stroke: {
                            show: true,
                            width: 2,
                            colors: ['transparent']
                        },
                        xaxis: {
                            categories: [
                                <?php $__currentLoopData = $tashrif['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    '<?php echo e($item); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],
                        },
                        yaxis: {
                            title: {
                            text: 'Tashriflar'
                            }
                        },
                        fill: {
                            opacity: 1
                        },
                        tooltip: {
                            y: {
                                formatter: function(val) {
                                    return val
                                }
                            }
                        }
                        }).render();
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered text-center" style="font-size:12px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <?php $__currentLoopData = $tashrif['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><b><?php echo e($item); ?></b></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th style="text-align:left;">Tashriflar</th>
                                <?php $__currentLoopData = $tashrif['tashrif']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th style="text-align:left;">Guruhga biriktirildi</th>
                                <?php $__currentLoopData = $tashrif['group']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th style="text-align:left;">To'lov qildi</th>
                                <?php $__currentLoopData = $tashrif['paymart']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th style="text-align:left;">Aktiv talabalar</th>
                                <?php $__currentLoopData = $activeUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/chart/vised.blade.php ENDPATH**/ ?>