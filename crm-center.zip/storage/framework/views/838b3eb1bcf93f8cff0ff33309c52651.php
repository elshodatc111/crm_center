<?php $__env->startSection('title','Tizim sozlamalari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Tizim sozlamalari</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Tizim sozlamalari</li>
            </ol>
        </nav>
    </div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Markaz nomini yangilash</h3>
                <form action="<?php echo e(route('sadmin_update_name')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="name">Markaz nomi</label>
                    <input type="text" name="name" value="<?php echo e($Setting['name']); ?>" required class="form-control">
                    <button type="submit" class="btn btn-primary w-100 mt-2">O'zgarishlarni saqlash</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Markaz holati (<?php echo e($Setting['status']=='true'?'Aktive':'Block'); ?>)</h3>
                <form action="<?php echo e(route('sadmin_update_status')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="status">Markaz holatini tanlang</label>
                    <select type="text" name="status" required class="form-select">
                        <option value="">Tanlang</option>
                        <option value="true">Aktiv</option>
                        <option value="false">Block</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100 mt-2">O'zgarishlarni saqlash</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/sadmin/index.blade.php ENDPATH**/ ?>