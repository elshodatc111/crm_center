<?php $__env->startSection('title','Qaytarilgan to\'lovlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Qaytarilgan to'lovlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Qaytarilgan to'lovlar</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Qaytarilgan to'lovlar</h3>
            <div class="table-responsive">
                <table class="table table-bordered text-center" style="font-size:14px;">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Talaba</th>
                            <th>Qaytariladigan to'lov</th>
                            <th>Qaytarish haqida</th>
                            <th>Meneger</th>
                            <th>Qaytarilgan vaqt</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $Refund; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><a href="<?php echo e(route('student_show',$item['user_id'])); ?>"><?php echo e($item['user_name']); ?></a></td>
                                <td><?php echo e($item['amonut']); ?></td>
                                <td><?php echo e($item['description']); ?></td>
                                <td><?php echo e($item['meneger']); ?></td>
                                <td><?php echo e($item['created_at']); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('all_student_return_del')); ?>" method="post">
                                        <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="id" value="<?php echo e($item['refund_id']); ?>">
                                        <button class="btn btn-danger p-0 px-1"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=7 class="text-center">Qaytarilgan to'lovlar mavjud emas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app03', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/student/return.blade.php ENDPATH**/ ?>