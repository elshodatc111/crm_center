<?php $__env->startSection('title','Guruh Statistika'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Guruhlar Statistikasi</h4>
                <div class="table-responsive">
                    <table class="table table-bordered text-center table-striped justify-content-center" style="font-size:14px;">
                        <thead style="font-size:14px;">
                            <tr>
                                <th rowspan=2>Guruhlar (Oxirgi 30 kunda yakunlangan guruhlar)</th>
                                <th colspan=2>Dars vaqtlari</th>
                                <th rowspan=2>Guruh talabalari</th>
                                <th colspan=2>Darslarni davom etgan talabalar</th>
                                <th rowspan=2>O'qituvchi</th>
                            </tr>
                            <tr>
                                <th>Boshlangan vaqt</th>
                                <th>Yakunlangan vaqti</th>
                                <th>Umumiy soni</th>
                                <th>To'lov qilganlar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th><a href="<?php echo e(route('create_show',$items['group_id'])); ?>"><?php echo e($items['group_name']); ?></a></th>
                                <td><?php echo e($items['lessen_start']); ?></td>
                                <td><?php echo e($items['lessen_end']); ?></td>
                                <td><?php echo e($items['user_count']); ?></td>
                                <td><?php echo e($items['next_count']); ?></td>
                                <td><?php echo e($items['paymart_count']); ?></td>
                                <td><a href="<?php echo e(route('techer_show',$items['techer_id'])); ?>"><?php echo e($items['techer']); ?></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=7 class="text-center">30 kun davomida yakunlangan guruhlar mavjud emas.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/chart/techer.blade.php ENDPATH**/ ?>