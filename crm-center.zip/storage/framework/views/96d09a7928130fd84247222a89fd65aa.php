<?php $__env->startSection('title','Yangi Murojatlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Yangi murojatlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_varonka')); ?>">Murojatlar</a></li>
                <li class="breadcrumb-item">Yangi murojatlar</li>
            </ol>
        </nav>
    </div>

    <div class="card">
        <div class="card-body pt-3">
            <div class="d-grid gap-2">
                <a class="btn btn-primary d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-envelope"></i> Yangi murojatlar</span>
                    <span class="badge bg-white text-primary"><?php echo e($count); ?></span>
                </a>
            </div>
            <table class="table table-bordered mt-2 text-center" style="font-size:14px">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Murojaatchi</th>
                        <th>Murojaatchi manzil</th>
                        <th>Murojaatchi telefon raqami</th>
                        <th>Murojaatchi ro‘yxatdan o‘tdi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($Varonka->count() > 0): ?>
                        <?php $__currentLoopData = $Varonka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($Varonka->firstItem() + $index); ?></td>
                                <td><a href="<?php echo e(route('meneger_varonka_show',$item->id )); ?>"><?php echo e($item->user_name); ?></a></td>
                                <td><?php echo e($item->address ?? 'Mavjud emas'); ?></td>
                                <td><?php echo e($item->phone1 ?? 'Mavjud emas'); ?></td>
                                <td><?php echo e($item->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">Murojaatlar mavjud emas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo e($Varonka->links('pagination::bootstrap-4')); ?>

            </div>

        </div>
    </div>
        




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/varonka/admin/new.blade.php ENDPATH**/ ?>