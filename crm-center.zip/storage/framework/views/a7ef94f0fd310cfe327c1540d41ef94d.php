
<?php $__env->startSection('title','To\'lov sozlamalari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>To'lov sozlamalari</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">To'lov sozlamalari</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi to'lov qo'shish</h3>
                    <form action="<?php echo e(route('settings_paymart_create')); ?>" method="POST">
                        <?php echo csrf_field(); ?> 
                        <div class="mb-1">
                            <label for="amount" class="form-label">Miqdor (amount)</label>
                            <input type="text" class="form-control" id="paymentAmount" name="amount" required>
                        </div>
                        <div class="mb-1">
                            <label for="chegirma" class="form-label">Chegirma (chegirma)</label>
                            <input type="text" class="form-control" id="paymentAmount1" name="chegirma">
                        </div>
                        <div class="mb-2">
                            <label for="admin_chegirma" class="form-label">Admin chegirma (admin_chegirma)</label>
                            <input type="text" class="form-control" id="paymentAmount2" name="admin_chegirma">
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-50">Saqlash</button>
                        </div>
                    </form>     
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Aktiv to'lov summasi</h2>
                    <table class="table table-bordered text-center" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>To'lov summasi</th>
                                <th>Chegirma Summasi</th>
                                <th>Admin uchun chegirma</th>
                                <th>Admin</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $activPaymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e(number_format($item['amount'], 0, '.', ' ')); ?></td>
                                <td><?php echo e(number_format($item['chegirma'], 0, '.', ' ')); ?></td>
                                <td><?php echo e(number_format($item['admin_chegirma'], 0, '.', ' ')); ?></td>
                                <td><?php echo e($item['user_id']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('settings_paymart_update')); ?>" method="post">
                                        <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button class="btn btn-danger px-1 py-0" type="submit"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan=6>To'lovlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">O'chirilgan to'lov summasi</h2>
                    <table class="table table-bordered text-center" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>To'lov summasi</th>
                                <th>Chegirma Summasi</th>
                                <th>Admin uchun chegirma</th>
                                <th>Admin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $deletePaymart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e(number_format($item['amount'], 0, '.', ' ')); ?></td>
                                <td><?php echo e(number_format($item['chegirma'], 0, '.', ' ')); ?></td>
                                <td><?php echo e(number_format($item['admin_chegirma'], 0, '.', ' ')); ?></td>
                                <td><?php echo e($item['user_id']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center" colspan=5>O'chirilgan to'lovlar mavjud emas.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<script>
    document.getElementById('paymentAmount').addEventListener('input', function(event) {
        let input = event.target.value.replace(/\D/g, ''); 
        let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        event.target.value = formatted;
    });
    document.getElementById('paymentAmount1').addEventListener('input', function(event) {
        let input = event.target.value.replace(/\D/g, ''); 
        let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        event.target.value = formatted;
    });
    document.getElementById('paymentAmount2').addEventListener('input', function(event) {
        let input = event.target.value.replace(/\D/g, ''); 
        let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        event.target.value = formatted;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/admin/setting/paymart/index.blade.php ENDPATH**/ ?>