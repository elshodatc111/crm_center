<?php $__env->startSection('title','Murojat haqida'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Murojat haqida</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('meneger_varonka')); ?>">Murojatlar</a></li>
            <li class="breadcrumb-item active">Murojat haqida</li>
        </ol>
    </nav>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card profile-card">
                <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                    <h2 class="text-primary"><?php echo e($user['user_name']); ?></h2>
                    <ul class="list-group w-100 mt-3">
                        <li class="list-group-item"><i class="bi bi-telephone"></i> <strong>Telefon 1:</strong> <?php echo e($user['phone1']); ?></li>
                        <li class="list-group-item"><i class="bi bi-telephone"></i> <strong>Telefon 2:</strong> <?php echo e($user['phone2']); ?></li>
                        <li class="list-group-item"><i class="bi bi-geo-alt"></i> <strong>Manzil:</strong> <?php echo e($user['address']); ?></li>
                        <li class="list-group-item"><i class="bi bi-calendar"></i> <strong>Tug‘ilgan sana:</strong> <?php echo e($user['birthday']); ?></li>
                        <li class="list-group-item"><i class="bi bi-check-circle"></i> <strong>Status:</strong> <?php echo e($user['status2']); ?></li>
                        <li class="list-group-item"><i class="bi bi-clock"></i> <strong>Murojaat vaqti:</strong> <?php echo e($user['created_at']); ?></li>
                        <li class="list-group-item"><i class="bi bi-globe"></i> <strong>Ijtimoiy tarmoq turi:</strong> <?php echo e($user['type_social']); ?></li>
                    </ul>
                </div> 
            </div>
            <?php if($user['status']!='cancel'): ?>
            <div class="row mb-2 px-2">
                <div class="col-12">
                    <?php if($user['register_id'] == 0): ?>
                    <button class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#cancelModal">
                        <i class="bi bi-x-circle"></i> Bekor qilish
                    </button>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <?php if(!$check): ?>
                        <?php if($user['register_id'] == 0): ?>
                            <?php if(!$status): ?>
                            <button class="btn btn-success mt-2 w-100" data-bs-toggle="modal" data-bs-target="#registerModal">
                                <i class="bi bi-check-circle"></i> Ro'yxatga olish
                            </button>
                            <?php endif; ?>
                        <?php else: ?>
                        <a class="btn btn-info text-white w-100 mt-2" href="<?php echo e(route('student_show', $user['register_id'])); ?>">
                            <i class="bi bi-person"></i> Ro'yxatga olingan
                        </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card">
            <div class="card-body chat-box p-3" id="chatBox" style="height: 400px; overflow-y: auto; background: #f8f9fa;">
                <h5 class="card-title w-100 text-center bg-white"><i class="bi bi-chat-dots"></i> Murojat haqida</h5>
                <div class="d-flex flex-column">
                    <?php if($check): ?>
                        <div class="d-flex justify-content-start mb-2">
                            <div class="p-3 bg-light border rounded shadow">
                                <strong>Ro'yhatdan o'tgan</strong> <i class="text-muted"><?php echo e($check['created_at']); ?></i>
                                <div class="small"><a href="<?php echo e(route('student_show',$check['id'])); ?>"><?php echo e($check['user_name']); ?></a> bu murojatchi oldin ro'yhatdan o'tgan.</div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-start mb-2">
                        <div class="p-3 bg-light border rounded shadow">
                            <strong><?php echo e($item['user_name']); ?></strong> <i class="text-muted"><?php echo e($item['created_at']); ?></i>
                            <div class="small"><?php echo e($item['comment']); ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="d-flex justify-content-start mb-2">
                            <div class="p-3 bg-light border rounded shadow">
                                <strong>Admin</strong></i>
                                <div class="small">Murojatchi haqida malumotlarni saqlab qo'yish uchun joy.</div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-footer">
                <?php if(!$check): ?>
                    <?php if($user['status']!='cancel'): ?>
                        <form action="<?php echo e(route('meneger_varonka_comments_post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="input-group">
                                <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                                <input type="text" name="comment" class="form-control" placeholder="Eslatma qoldiring..." required>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i></button>
                            </div>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="cancelModal" tabindex="-1" aria-labelledby="cancelModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="cancelModalLabel">Bekor qilish</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('meneger_varonka_cancel_post')); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    Ishonchingiz komilmi? Ushbu murojaatni bekor qilmoqchimisiz?
                    <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-6"><button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Yo‘q</button></div>
                        <div class="col-6"><button type="submit" class="btn btn-danger w-100">Ha, bekor qilish</button></div>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
</div>

<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="registerModalLabel">Ro‘yxatga olish</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('meneger_varonka_register_post')); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                    <label for="about">Ro'yhatga olish haqida</label>
                    <textarea name="about" required class="form-control mb-3"></textarea>
                    <div class="row">
                        <div class="col-6">
                            <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal">Bekor qilish</button>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-success w-100">Ro‘yxatga olish</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    document.getElementById('chatBox').scrollTop = document.getElementById('chatBox').scrollHeight;
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app03', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/varonka/admin/show.blade.php ENDPATH**/ ?>