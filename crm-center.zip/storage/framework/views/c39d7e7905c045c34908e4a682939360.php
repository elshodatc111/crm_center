<?php $__env->startSection('title','O\'qituvchi Reyting'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">O'qituvchilar reytingi</h4>
                <div class="table-responsive">
                    <table class="table table-bordered text-center table-striped" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th rowspan="2">#</th>
                                <th rowspan="2">O‘qituvchi</th>
                                <th rowspan="2">Guruhlar soni</th>
                                <th colspan="3">Bitiruvchilar</th>
                                <th rowspan="2">Reyting</th>
                            </tr>
                            <tr>
                                <th>Guruhdagi talabalar soni</th>
                                <th>Darslarni davom ettirgan talabalar soni</th>
                                <th>Darslarni davom ettirib, to‘lov qilgan talabalar soni</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $techer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td style="text-align:left"><a href="<?php echo e(route('techer_show',$item['techer_id'])); ?>"><?php echo e($item['techer']); ?></a></td>
                                <td><?php echo e($item['group_count']); ?></td>
                                <td><?php echo e($item['count_user']); ?></td>
                                <td><?php echo e($item['next_count_user']); ?></td>
                                <td><?php echo e($item['paymart_count_user']); ?></td>
                                <td><?php echo e($item['reyting']); ?> %</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center">O'qituvchilar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/chart/reyting.blade.php ENDPATH**/ ?>