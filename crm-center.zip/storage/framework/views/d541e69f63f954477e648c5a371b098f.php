
<?php $__env->startSection('title','Kurs sozlamalari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Kurs sozlamalari</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Kurs sozlamalari</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi kurs qo'shish</h3> 
                    <form action="<?php echo e(route('setting_cours_create')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <label for="cours_name">Kursning nomi</label>
                        <input type="text" name="cours_name" required class="form-control my-2">
                        <button class="btn btn-primary w-100 mt-2">Kursni saqlash</button>
                    </form>      
                </div>
            </div>
        </div>
        <div class="col-9">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Kurslar</h3>    
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kurs nomi</th>
                                <th>Video Darslar soni</th>
                                <th>Testlar Soni</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['cours_name']); ?></td>
                                <td><a href="<?php echo e(route('setting_cours_video', $item['id'])); ?>"><?php echo e($item['video']); ?></a></td>
                                <td><a href="<?php echo e(route('setting_cours_test', $item['id'])); ?>"><?php echo e($item['test']); ?></a></td>
                                <td>
                                    <form action="<?php echo e(route('setting_cours_update')); ?>" method="post">
                                        <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button type="submit" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=5 class="text-center">Kurslar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>   
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/admin/setting/cours/index.blade.php ENDPATH**/ ?>