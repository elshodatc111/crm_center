
<?php $__env->startSection('title','Chegirmali to\'lovlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Chegirmali to'lovlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Chegirmali to'lovlar</li>
            </ol>
            <p class="text-danger">Chegirmali to'lov faqat bittasi aktiv bo'lishi mumkun</p>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi chegirmali to'liv</h3>
                    <form action="<?php echo e(route('setting_chegirma_create')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <label for="amount" class="mb-1">Chegirmali to'lov summasi</label>
                        <input type="text" id="paymentAmount" name="amount" required class="form-control">
                        <label for="chegirma" class="my-1">To'lov uchun chegirma</label>
                        <input type="text" id="paymentAmount1" name="chegirma" required class="form-control">
                        <label for="comment" class="my-1">To'lov haqida</label>
                        <textarea type="text" name="comment" required class="form-control"></textarea>
                        <button class="btn btn-primary w-100 mt-2">Saqlash</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Chegirmali to'lovlar</h3>
                    <table class="table table-bordered text-center" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>To'lov summasi</th>
                                <th>Chegirmas summasi</th>
                                <th>Chegirma haqida</th>
                                <th>Status</th>
                                <th>Sozlama</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $chegirma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e(number_format($item['amount'], 0, '.', ' ')); ?></td>
                                <td><?php echo e(number_format($item['chegirma'], 0, '.', ' ')); ?></td>
                                <td><?php echo e($item['comment']); ?></td>
                                <td><?php if($item['status']=='true'): ?>
                                        <span class="badge bg-success">Aktiv</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Delete</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($item['status']=='true'): ?>
                                        <form action="<?php echo e(route('setting_chegirma_update')); ?>" method="post">
                                            <?php echo csrf_field(); ?> 
                                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                            <button type="submit" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=6 class="text-center">Chegirmalar mavjud emas.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                        
                </div>
            </div>
        </div>
    </div>
<script>
    document.getElementById('paymentAmount').addEventListener('input', function(event) {
        let input = event.target.value.replace(/\D/g, ''); 
        let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        event.target.value = formatted;
    });
    document.getElementById('paymentAmount1').addEventListener('input', function(event) {
        let input = event.target.value.replace(/\D/g, ''); 
        let formatted = input.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
        event.target.value = formatted;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm-center\resources\views/admin/setting/chegirma/index.blade.php ENDPATH**/ ?>