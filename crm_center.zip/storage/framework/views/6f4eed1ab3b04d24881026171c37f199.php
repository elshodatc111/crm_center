<?php $__env->startSection('title','Kurs video darslar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1><?php echo e($cours['cours_name']); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('setting_cours')); ?>">Kurs sozlamalari</a></li>
                <li class="breadcrumb-item">Kurs video darslar</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi video dars qo'shish</h3> 
                    <form action="<?php echo e(route('setting_video_create')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <input type="hidden" name="cours_id" value="<?php echo e($cours['id']); ?>">
                        <label for="cours_name">Mavzu nomi</label>
                        <input type="text" name="cours_name" required class="form-control my-2">
                        <label for="lessen_number">Tartib raqami</label>
                        <input type="number" name="lessen_number" required class="form-control my-2">
                        <label for="video_url">Youtube video url</label>
                        <input type="text" name="video_url" required class="form-control my-2">
                        <button class="btn btn-primary w-100 mt-2">Darsni saqlash</button>
                    </form>      
                </div>
            </div>
        </div>
        <div class="col-9">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Videodarslar</h3>    
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Mavzu</th>
                                <th>Tartib raqami</th>
                                <th>Video URL</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['cours_name']); ?></td>
                                <td><?php echo e($item['lessen_number']); ?></td>
                                <td><?php echo e($item['video_url']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('setting_video_delete')); ?>" method="post">
                                        <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                        <button class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=5 class="text-center">Video darslar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>   
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app03', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm_center\resources\views/admin/setting/cours/video.blade.php ENDPATH**/ ?>