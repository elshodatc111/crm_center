<?php $__env->startSection('title','Dars vaqtlari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Dars vaqtlari</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Dars vaqtlari</li>
            </ol>
        </nav>
    </div>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Dars vaqtlari</h3>
                <table class="table text-center table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Dars vaqti</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $LessenTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['number']); ?></td>
                            <td><?php echo e($item['time']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Dars vaqtlarini sozlash</h3>
                <?php if(count($LessenTime)==0): ?>
                <form action="<?php echo e(route('sadmin_time_store')); ?>" method="post">
                    <?php echo csrf_field(); ?> 
                    <label for="start">Dars boshlanish vaqti</label>
                    <input type="time" name="start" required class="form-control">
                    <label for="time">Dars vaqti(minut)</label>
                    <input type="number" name="time" required class="form-control">
                    <label for="count">Darslar soni</label>
                    <input type="number" name="count" required class="form-control">
                    <button class="btn btn-primary w-100 mt-2" type="submit">Saqlash</button>
                </form>
                <?php else: ?>
                    <form action="<?php echo e(route('sadmin_time_delete')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <button class="btn btn-danger w-100 mt-2" type="submit">Barcha dars vaqtlarini o'chirish</button>
                    </form>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm_center\resources\views/sadmin/time.blade.php ENDPATH**/ ?>