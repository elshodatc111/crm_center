<?php $__env->startSection('title','Murojatlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Murojatlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Bosh sahifa</a></li>
                <li class="breadcrumb-item">Murojatlar</li>
            </ol>
        </nav>
    </div>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card">
            <div class="card-body pt-3">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('meneger_varonka_new')); ?>" class="btn btn-outline-primary d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-envelope"></i> Yangi murojatlar</span>
                        <span class="badge bg-white text-primary"><?php echo e($charts['new']); ?></span>
                    </a>
                    <a href="<?php echo e(route('meneger_varonka_pedding')); ?>" class="btn btn-outline-warning d-flex justify-content-between align-items-center text-dark">
                        <span><i class="bi bi-eye"></i> Ko‘rib chiqilmoqda</span>
                        <span class="badge bg-white text-warning"><?php echo e($charts['pedding']); ?></span>
                    </a>
                    <a href="<?php echo e(route('meneger_varonka_success')); ?>" class="btn btn-outline-info d-flex justify-content-between align-items-center text-success">
                        <span><i class="bi bi-check-circle"></i> Qabul qilindi</span>
                        <span class="badge bg-white text-info"><?php echo e($charts['success']); ?></span>
                    </a>
                    <a href="<?php echo e(route('meneger_varonka_cancel')); ?>" class="btn btn-outline-danger d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-x-circle"></i> Bekor qilindi</span>
                        <span class="badge bg-white text-danger"><?php echo e($charts['cancel']); ?></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card">
            <div class="card-body pt-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover justify-content-center" style="font-size:12px;">
                        <tbody>
                            <tr>
                                <td class="text-center"><i class="bi bi-telegram text-primary"></i> Telegram</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_telegram'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_telegram'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-instagram text-danger"></i> Instagram</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_instagram'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-danger" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_instagram'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-facebook text-primary"></i> Facebook</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_facebook'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-primary" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_facebook'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-youtube text-danger"></i> YouTube</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_youtube'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-danger" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_youtube'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-image text-warning"></i> Bannerlar</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_banner'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-warning" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_banner'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-people text-success"></i> Tanishlar</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_tanish'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-success" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_tanish'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-center"><i class="bi bi-link-45deg text-secondary"></i> Boshqalar</td>
                                <td><input type="text" class="form-control" value="<?php echo e(env('APP_URL').'/varonka/user/social_boshqa'); ?>" readonly></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-outline-secondary" onclick="copyToClipboard('<?php echo e(env('APP_URL').'/varonka/user/social_boshqa'); ?>')">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <script>
                function copyToClipboard(text) {
                    navigator.clipboard.writeText(text).then(() => {
                        alert('Havola nusxalandi: ' + text);
                    }).catch(err => {
                        console.error('Nusxalashda xatolik yuz berdi: ', err);
                    });
                }
            </script>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm_center\resources\views/varonka/admin/index.blade.php ENDPATH**/ ?>