<?php $__env->startSection('title','Kurs testlari'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1><?php echo e($cours['cours_name']); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('setting_cours')); ?>">Kurs sozlamalari</a></li>
                <li class="breadcrumb-item">Kurs testlari</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi test qo'shish</h3> 
                    <form action="<?php echo e(route('setting_test_create')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <input type="hidden" name="cours_id" value="<?php echo e($cours['id']); ?>">
                        <label for="test">Test Savoli</label>
                        <input type="text" name="test" required class="form-control my-2">
                        <label for="javob_true">To'g'ri javob</label>
                        <input type="text" name="javob_true" required class="form-control my-2">
                        <label for="javob_false_first">Noto'g'ri javob</label>
                        <input type="text" name="javob_false_first" required class="form-control my-2">
                        <label for="javob_false_two">Noto'g'ri javob</label>
                        <input type="text" name="javob_false_two" required class="form-control my-2">
                        <label for="javob_false_thre">Noto'g'ri javob</label>
                        <input type="text" name="javob_false_thre" required class="form-control my-2">
                        <button type="submit" class="btn btn-primary w-100 mt-2">Testni saqlash</button>
                    </form>      
                </div>
            </div>
        </div>
        <div class="col-9">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Testlar</h3>    
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Savol</th>
                                <th>To'g'ri javob</th>
                                <th>Noto'g'ri javob</th>
                                <th>Noto'g'ri javob</th>
                                <th>Noto'g'ri javob</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($item['test']); ?></td>
                                    <td><?php echo e($item['javob_true']); ?></td>
                                    <td><?php echo e($item['javob_false_first']); ?></td>
                                    <td><?php echo e($item['javob_false_two']); ?></td>
                                    <td><?php echo e($item['javob_false_thre']); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('setting_test_delete')); ?>" method="post">
                                            <?php echo csrf_field(); ?> 
                                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                            <button class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=7 class="text-center">Testlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>   
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app03', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm_center\resources\views/admin/setting/cours/test.blade.php ENDPATH**/ ?>