<?php $__env->startSection('title','Hududlar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Hududlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item">Hududlar</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?> 
    <div class="row">
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Hududlar</h3>  
                    <table class="table table-bordered text-center" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Hudud nomi</th>
                                <th>Tashriflar soni</th>
                                <th>O'chirish</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($item['name']); ?></td>
                                <td><?php echo e($item['count']); ?></td>
                                <td>
                                    <form action="<?php echo e(route('social_delete',$item['id'])); ?>" method="post">
                                        <?php echo csrf_field(); ?> 
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger px-1 py-0" type="submit"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=4 class="text-center">Hududlar mavjud emas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>     
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Yangi hudud</h3>     
                    <form action="<?php echo e(route('social_store')); ?>" method="post">
                        <?php echo csrf_field(); ?> 
                        <label for="name" class="mb-2">Yangi hudud nomi</label>
                        <input type="text" name="name" class="form-control" required>
                        <button class="btn btn-primary w-100 mt-2">Saqlash</button>
                    </form>  
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm_center\resources\views/admin/setting/social/index.blade.php ENDPATH**/ ?>